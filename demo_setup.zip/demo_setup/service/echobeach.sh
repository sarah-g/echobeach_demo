#!/bin/bash
# Node startup script

echo "running script as user: root"
su -c "killall node ; source /home/root/miniconda2/bin/activate root ; cd /node_app_slot ; node main.js" -m "root"

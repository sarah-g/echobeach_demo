#!bin/bash
#setup script for EchoBeach bat classification platform

echo "[1] configuring logging..."
sed -i -e "s/\(Storage=\).*/\1none/" /etc/systemd/journald.conf
rm -rf /var/log/journal/*
echo "configuring logging...complete/n"

echo "upgrading tar..."
opkg install ./tar/tar_1.27.1-r0_core2-32.ipk
echo "upgrading tar...complete/n"

echo "installing miniconda..."
bash ./miniconda/Miniconda2-latest-Linux-x86.sh
echo "installing miniconda...complete/n"

echo "installing echobeach service..."
cp ./service/echobeach.sh /usr/bin/
chmod +x /usr/bin/echobeach.sh
cp ./service/echobeach.service /etc/systemd/system/
systemctl enable echobeach.service
systemctl daemon-reload
echo "installing echobeach service...complete/n"

echo "creating recordings directory..."
mkdir /media/sdcard/recordings
echo "creating recordings directory...complete/n"

echo "\n\nSetup Complete!"
echo "\n\nTo start demo service, restart device OR type: systemctl start node_startup.service\n"
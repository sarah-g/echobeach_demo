Demo code is on github:

Use XDK IoT edition to edit and upload code to Edison

